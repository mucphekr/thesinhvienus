// Popup Script

document.addEventListener('DOMContentLoaded', () => {
    // Cập nhật trạng thái
    updateStatus();
    
    // Load URL đã lưu (nếu có)
    chrome.storage.local.get(['lastSheeridUrl'], (result) => {
        if (result.lastSheeridUrl) {
            document.getElementById('sheeridUrl').value = result.lastSheeridUrl;
        }
    });
    
    // Bắt đầu Auto Fill
    document.getElementById('startAutoFill').addEventListener('click', () => {
        const urlInput = document.getElementById('sheeridUrl');
        const errorMsg = document.getElementById('errorMsg');
        const url = urlInput.value.trim();
        
        // Validate URL
        if (!url || !url.includes('sheerid.com')) {
            errorMsg.classList.add('show');
            urlInput.style.borderColor = '#ff4b2b';
            return;
        }
        
        // Hide error
        errorMsg.classList.remove('show');
        urlInput.style.borderColor = 'rgba(102, 126, 234, 0.3)';
        
        // Lưu URL
        chrome.storage.local.set({ lastSheeridUrl: url });
        
        // Gửi message đến background để bắt đầu quy trình
        chrome.runtime.sendMessage({
            action: 'START_FROM_POPUP',
            url: url
        }, (response) => {
            if (response && response.success) {
                // Cập nhật UI
                document.getElementById('statusText').textContent = 'Đang xử lý...';
                document.getElementById('statusText').className = 'status-value processing';
                
                // Đóng popup
                window.close();
            }
        });
    });
    
    // Enter key để submit
    document.getElementById('sheeridUrl').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('startAutoFill').click();
        }
    });
    
    // Clear error khi nhập
    document.getElementById('sheeridUrl').addEventListener('input', () => {
        document.getElementById('errorMsg').classList.remove('show');
        document.getElementById('sheeridUrl').style.borderColor = 'rgba(102, 126, 234, 0.3)';
    });
    
    // Xóa link
    document.getElementById('clearUrl').addEventListener('click', () => {
        document.getElementById('sheeridUrl').value = '';
        document.getElementById('errorMsg').classList.remove('show');
        document.getElementById('sheeridUrl').style.borderColor = 'rgba(102, 126, 234, 0.3)';
        chrome.storage.local.remove('lastSheeridUrl');
        document.getElementById('sheeridUrl').focus();
    });
    
    // Mở SheerID Google One
    document.getElementById('openSheerID').addEventListener('click', () => {
        chrome.tabs.create({
            url: 'https://gemini.google/students/'
        });
    });
    
    // Mở Generator
    document.getElementById('openGenerator').addEventListener('click', () => {
        chrome.tabs.create({
            url: 'https://nguyenbaviet.io.vn/'
        });
    });
});

// Cập nhật trạng thái hiển thị
function updateStatus() {
    chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (response) => {
        if (response) {
            const statusText = document.getElementById('statusText');
            const scriptStatus = document.getElementById('scriptStatus');
            
            // Cập nhật trạng thái
            const statusMap = {
                'idle': { text: 'Sẵn sàng', class: 'idle' },
                'generating': { text: 'Đang tạo...', class: 'generating' },
                'ready': { text: 'Script sẵn sàng', class: 'ready' },
                'filling': { text: 'Đang điền form', class: 'filling' },
                'processing': { text: 'Đang xử lý...', class: 'processing' }
            };
            
            const status = statusMap[response.status] || statusMap['idle'];
            statusText.textContent = status.text;
            statusText.className = 'status-value ' + status.class;
            
            // Cập nhật script status
            scriptStatus.textContent = response.hasScript ? '✅ Đã có' : '❌ Chưa có';
            scriptStatus.style.color = response.hasScript ? '#38ef7d' : '#888';
        }
    });
}

// Cập nhật mỗi 2 giây
setInterval(updateStatus, 2000);
