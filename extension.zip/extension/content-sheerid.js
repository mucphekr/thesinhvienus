// Content Script cho trang SheerID
// Xử lý tất cả các bước xác minh

console.log('🔵 SheerID Content Script loaded');
console.log('📍 Current URL:', window.location.href);

// Kiểm tra trạng thái trang hiện tại
function detectPageState() {
    const pageText = document.body?.innerText || '';
    const pageTextLower = pageText.toLowerCase();
    
    // 1. Kiểm tra Upload Proof page TRƯỚC (ưu tiên cao nhất)
    const uploadBtn = document.querySelector('.sid-sso-pending-submit-btn');
    const hasUploadText = pageTextLower.includes('upload proof');
    const hasUnableText = pageTextLower.includes('unable to sign in');
    
    if (uploadBtn || hasUploadText || hasUnableText) {
        console.log('🔍 Detected UPLOAD_PAGE');
        return 'UPLOAD_PAGE';
    }
    
    // 2. Kiểm tra SSO page - tìm nút SSO submit
    const ssoBtn = document.querySelector('#sid-submit-btn-sso, .sid-sso-submit-btn, button[class*="sso-submit"]');
    
    // Các biến thể text của trang SSO (nhiều ngôn ngữ)
    const ssoTexts = [
        'sign in to your school',
        'sign into my academic',
        'academic institution',
        'school credentials',
        'school\'s web portal',
        'verify using your school',
        'verify using academic',
        'đăng nhập vào trường',
        'login to your school'
    ];
    
    const hasSSOText = ssoTexts.some(text => pageTextLower.includes(text));
    
    if (ssoBtn || hasSSOText) {
        console.log('🔍 Detected SSO_PAGE');
        return 'SSO_PAGE';
    }
    
    // 3. Form page
    if (pageTextLower.includes('verify your student status') || pageTextLower.includes('country*')) {
        return 'FORM_PAGE';
    }
    
    // 4. Success page
    if (pageTextLower.includes('verification is complete') || pageTextLower.includes('successfully verified')) {
        return 'SUCCESS_PAGE';
    }
    
    return 'UNKNOWN';
}

// Tạo nút điều khiển
function createControlButton() {
    if (document.getElementById('sheerid-auto-btn')) return;
    
    const btn = document.createElement('button');
    btn.id = 'sheerid-auto-btn';
    btn.innerHTML = '🎓 Auto Fill Student';
    btn.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 999999;
        padding: 12px 24px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 25px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        transition: all 0.3s ease;
        font-family: Arial, sans-serif;
    `;
    
    btn.onmouseover = () => {
        btn.style.transform = 'translateY(-2px)';
        btn.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.6)';
    };
    btn.onmouseout = () => {
        btn.style.transform = 'translateY(0)';
        btn.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.4)';
    };
    
    btn.onclick = startAutoFill;
    document.body.appendChild(btn);
    console.log('✅ Control button created');
}

function updateButton(text, color) {
    const btn = document.getElementById('sheerid-auto-btn');
    if (btn) {
        btn.innerHTML = text;
        btn.style.background = color;
    }
}

// Bắt đầu quy trình
function startAutoFill() {
    updateButton('⏳ Đang tạo...', 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)');
    
    chrome.runtime.sendMessage({
        action: 'START_PROCESS',
        url: window.location.href
    });
}

// Lắng nghe message
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('📩 SheerID received:', message.action);
    
    if (message.action === 'FILL_FORM' && message.script) {
        console.log('🚀 Starting form fill...');
        
        // Parse data từ script
        const data = parseScriptData(message.script);
        console.log('📋 Parsed data:', data);
        
        if (data.firstName) {
            fillForm(data);
        }
        
        sendResponse({ success: true });
    }
    
    return true;
});

// Parse data từ script string
function parseScriptData(script) {
    const get = (key) => {
        const match = script.match(new RegExp(`${key}: "([^"]+)"`));
        return match ? match[1] : '';
    };
    
    return {
        country: get('country') || 'United States',
        schoolName: get('schoolName'),
        firstName: get('firstName'),
        lastName: get('lastName'),
        birthDay: get('birthDay'),
        birthMonth: get('birthMonth'),
        birthYear: get('birthYear'),
        email: get('email')
    };
}

// ==================== FORM FILLING LOGIC ====================

// Kiểm tra và đổi ngôn ngữ sang English
async function ensureEnglishLanguage() {
    const delay = ms => new Promise(r => setTimeout(r, ms));
    
    console.log('🌐 Checking language...');
    updateButton('🌐 Đổi ngôn ngữ...', 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)');
    
    // Tìm language selector bằng ID chính xác
    const langSelector = document.querySelector('#changeLanguageSelector-input');
    
    if (!langSelector) {
        console.log('❌ Language selector not found (#changeLanguageSelector-input)');
        return false;
    }
    
    console.log('📍 Found language selector:', langSelector.id);
    console.log('📍 Current value:', langSelector.value);
    
    // Kiểm tra giá trị hiện tại
    const currentValue = (langSelector.value || '').trim();
    
    // Nếu đã là "English" thì không cần đổi
    if (currentValue === 'English' || currentValue.toLowerCase() === 'english') {
        console.log('✅ Language is already English');
        return true;
    }
    
    // Nếu là bất kỳ ngôn ngữ nào khác, cần đổi sang English
    console.log('🔄 Current language:', currentValue, '- Changing to English...');
    
    // Scroll vào view
    langSelector.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await delay(500);
    
    // Click vào selector để mở dropdown
    console.log('🖱️ Clicking language selector...');
    langSelector.focus();
    await delay(200);
    
    // Click event
    langSelector.click();
    await delay(300);
    
    // Dispatch mouse events
    langSelector.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
    await delay(100);
    langSelector.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
    await delay(100);
    langSelector.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    await delay(500);
    
    // Đợi dropdown menu xuất hiện - tìm menu theo aria-controls
    const menuId = langSelector.getAttribute('aria-controls');
    console.log('📍 Looking for menu:', menuId);
    
    let menu = null;
    let attempts = 0;
    while (!menu && attempts < 20) {
        await delay(100);
        menu = document.querySelector(`#${menuId}`) || 
               document.querySelector('[id*="changeLanguageSelector-menu"]') ||
               document.querySelector('[role="listbox"]');
        attempts++;
    }
    
    if (!menu) {
        console.log('⚠️ Menu not found, trying to find any dropdown...');
        // Thử click lại
        langSelector.click();
        await delay(1000);
        menu = document.querySelector('[role="listbox"]') || 
                document.querySelector('[role="menu"]') ||
                document.querySelector('ul[role="listbox"]');
    }
    
    if (!menu) {
        console.log('❌ Could not find dropdown menu');
        return false;
    }
    
    console.log('✅ Found menu:', menu.id || menu.className);
    
    // Tìm tất cả options trong menu
    const options = menu.querySelectorAll('li, [role="option"], [data-option-index]');
    console.log('Found options:', options.length);
    
    // In ra tất cả options để debug
    options.forEach((opt, idx) => {
        const text = (opt.innerText || opt.textContent || '').trim();
        console.log(`Option ${idx}:`, text);
    });
    
    let found = false;
    
    // Ưu tiên tìm "English" (chính xác)
    for (const opt of options) {
        const optText = (opt.innerText || opt.textContent || '').trim();
        if (optText === 'English') {
            console.log('✅ Found English:', optText);
            opt.scrollIntoView({ behavior: 'smooth', block: 'center' });
            await delay(300);
            
            // Click vào option
            opt.focus();
            opt.click();
            opt.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
            await delay(200);
            
            found = true;
            break;
        }
    }
    
    // Nếu không tìm thấy "English" chính xác, tìm bất kỳ English nào (English (UK), English (US), etc.)
    if (!found) {
        for (const opt of options) {
            const optText = (opt.innerText || opt.textContent || '').toLowerCase().trim();
            if (optText.includes('english')) {
                console.log('✅ Found English variant:', optText);
                opt.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await delay(300);
                opt.focus();
                opt.click();
                opt.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
                found = true;
                break;
            }
        }
    }
    
    if (!found) {
        console.log('❌ English option not found in menu');
        // Đóng dropdown
        document.body.click();
        return false;
    }
    
    // Đợi trang reload/update sau khi chọn ngôn ngữ
    console.log('⏳ Waiting for language change to apply...');
    await delay(4000);
    
    // Kiểm tra lại - kiểm tra cả text trang và giá trị selector
    const newLangSelector = document.querySelector('#changeLanguageSelector-input');
    const newValue = newLangSelector ? (newLangSelector.value || '').trim() : '';
    const newPageText = document.body.innerText.toLowerCase();
    const nowEnglish = newPageText.includes('country') || newPageText.includes('first name') || newPageText.includes('verify your');
    
    // Kiểm tra xem đã đổi sang English chưa
    if (newValue === 'English' || newValue.toLowerCase() === 'english') {
        console.log('✅ Language changed to English successfully!');
        return true;
    } else if (nowEnglish) {
        console.log('✅ Page is in English, selector shows:', newValue);
        return true;
    } else {
        console.log('⚠️ Language may not have changed. Selector value:', newValue);
        return false;
    }
}

async function fillForm(CONFIG) {
    const delay = ms => new Promise(r => setTimeout(r, ms));
    
    updateButton('🌐 Kiểm tra ngôn ngữ...', 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)');
    
    const findInput = (selectors) => {
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) return el;
        }
        return null;
    };
    
    const fillInput = async (el, value) => {
        if (!el || !value) return false;
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(300);
        el.focus();
        await delay(100);
        el.click();
        await delay(100);
        el.value = '';
        el.dispatchEvent(new Event('input', { bubbles: true }));
        await delay(100);
        
        for (const char of value.toString()) {
            el.value += char;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            await delay(40);
        }
        
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('blur', { bubbles: true }));
        await delay(400);
        console.log('✅ Filled:', value);
        return true;
    };
    
    const selectOption = async (searchText, waitTime = 1500) => {
        await delay(waitTime);
        const options = document.querySelectorAll('[role="option"], [role="listbox"] li, .MuiAutocomplete-option, [data-option-index], ul li');
        
        for (const opt of options) {
            const optText = (opt.innerText || opt.textContent || '').toLowerCase();
            if (optText.includes(searchText.toLowerCase())) {
                opt.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await delay(200);
                opt.click();
                console.log('✅ Selected:', searchText);
                await delay(500);
                return true;
            }
        }
        console.log('⚠️ Option not found:', searchText);
        return false;
    };
    
    try {
        console.log('🚀 Bắt đầu điền form...');
        
        // Đợi trang load ổn định trước khi đổi ngôn ngữ
        console.log('⏳ Đợi trang load ổn định (2.5s)...');
        await delay(2500);
        
        // 1. KIỂM TRA VÀ ĐỔI NGÔN NGỮ SANG ENGLISH TRƯỚC
        const langOK = await ensureEnglishLanguage();
        if (!langOK) {
            console.log('⚠️ Could not verify English language, but continuing...');
        }
        await delay(1000);
        
        updateButton('📝 Đang điền...', 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)');
        
        // 2. Country
        console.log('🌍 Country...');
        const countryInput = findInput(['input[id*="country" i]', 'input[name*="country" i]', '[placeholder*="Country" i]']);
        if (countryInput) {
            await fillInput(countryInput, CONFIG.country);
            await selectOption(CONFIG.country, 2000);
        }
        await delay(500);
        
        // 3. School
        console.log('🏫 School...');
        const schoolInput = findInput(['input[id*="college" i]', 'input[id*="school" i]', 'input[id*="organization" i]', '[placeholder*="search" i]']);
        if (schoolInput) {
            const shortSchool = CONFIG.schoolName.split('(')[0].trim();
            await fillInput(schoolInput, shortSchool);
            
            // Đợi dropdown xuất hiện và danh sách school load xong
            console.log('⏳ Đợi danh sách school load...');
            await delay(2000);
            
            // Đợi cho đến khi có options trong dropdown (tối đa 5 giây)
            let optionsLoaded = false;
            for (let i = 0; i < 25; i++) {
                const options = document.querySelectorAll('[role="option"], [role="listbox"] li, .MuiAutocomplete-option, [data-option-index], ul li');
                if (options.length > 0) {
                    console.log('✅ School options loaded:', options.length);
                    optionsLoaded = true;
                    break;
                }
                await delay(200);
            }
            
            if (!optionsLoaded) {
                console.log('⚠️ School options may not be loaded yet, but continuing...');
            }
            
            // Thêm delay để đảm bảo danh sách đã load hoàn toàn
            await delay(1000);
            
            // Chọn school với waitTime dài hơn
            await selectOption(shortSchool.substring(0, 20), 3000);
            
            // Đợi sau khi chọn để đảm bảo đã chọn xong
            await delay(1000);
        }
        await delay(500);
        
        // 4. First Name
        console.log('👤 First Name...');
        const firstNameInput = findInput(['input[id*="first" i]', 'input[name*="first" i]', '[placeholder*="First" i]']);
        if (firstNameInput) await fillInput(firstNameInput, CONFIG.firstName);
        await delay(300);
        
        // 5. Last Name
        console.log('👤 Last Name...');
        const lastNameInput = findInput(['input[id*="last" i]', 'input[name*="last" i]', '[placeholder*="Last" i]']);
        if (lastNameInput) await fillInput(lastNameInput, CONFIG.lastName);
        await delay(300);
        
        // 6. Month
        console.log('📅 Month...');
        const monthInput = findInput(['input[id*="month" i]', '[placeholder="Month"]']);
        if (monthInput) {
            monthInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
            await delay(200);
            monthInput.click();
            await delay(500);
            await selectOption(CONFIG.birthMonth, 800);
        }
        await delay(300);
        
        // 7. Day
        console.log('📅 Day...');
        const dayInput = findInput(['input[id*="day" i]', '[placeholder="Day"]']);
        if (dayInput) await fillInput(dayInput, CONFIG.birthDay);
        await delay(300);
        
        // 8. Year
        console.log('📅 Year...');
        const yearInput = findInput(['input[id*="year" i]', '[placeholder="Year"]']);
        if (yearInput) await fillInput(yearInput, CONFIG.birthYear);
        await delay(300);
        
        // 9. Email
        console.log('📧 Email...');
        const emailInput = findInput(['input[id*="email" i]', 'input[type="email"]', '[placeholder*="email" i]']);
        if (emailInput) await fillInput(emailInput, CONFIG.email);
        await delay(500);
        
        console.log('✅ HOÀN THÀNH ĐIỀN FORM!');
        
        // 10. Click Verify
        await delay(1000);
        await clickVerifyButton();
        
        updateButton('✅ Đã gửi!', 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)');
        
    } catch (error) {
        console.error('❌ Error:', error);
        updateButton('❌ Lỗi!', 'linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%)');
    }
}

// Click nút Verify student status
async function clickVerifyButton() {
    const delay = ms => new Promise(r => setTimeout(r, ms));
    
    console.log('🔍 Tìm nút Verify...');
    
    const allBtns = [...document.querySelectorAll('button, [role="button"], input[type="submit"]')];
    let verifyBtn = allBtns.find(el => {
        const text = (el.innerText || el.textContent || '').toLowerCase();
        return text.includes('verify student') || text.includes('verify my student');
    });
    
    if (!verifyBtn) {
        verifyBtn = allBtns.find(el => (el.innerText || '').toLowerCase().includes('verify'));
    }
    
    if (verifyBtn && !verifyBtn.disabled) {
        verifyBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(500);
        verifyBtn.click();
        console.log('✅ Clicked Verify!');
    }
}

// ==================== SSO PAGE HANDLING ====================

async function handleSSOPage() {
    const delay = ms => new Promise(r => setTimeout(r, ms));
    
    console.log('🔐 Đang ở trang SSO, tìm nút Sign in...');
    
    // Lưu URL hiện tại
    const currentUrl = window.location.href;
    chrome.storage.local.set({ returnUrl: currentUrl });
    
    await delay(1000);
    
    // Tìm nút SSO bằng nhiều cách
    let ssoBtn = document.querySelector('#sid-submit-btn-sso');
    
    if (!ssoBtn) {
        ssoBtn = document.querySelector('.sid-sso-submit-btn');
    }
    
    if (!ssoBtn) {
        ssoBtn = document.querySelector('button[class*="sso-submit"]');
    }
    
    // Tìm bằng text (nhiều biến thể ngôn ngữ)
    if (!ssoBtn) {
        const ssoTexts = [
            'sign in to your school',
            'sign into my academic',
            'sign in to my academic',
            'đăng nhập vào trường',
            'login to your school',
            'sign in to school'
        ];
        
        const allBtns = [...document.querySelectorAll('button, [role="button"]')];
        ssoBtn = allBtns.find(btn => {
            const text = (btn.innerText || btn.textContent || '').toLowerCase();
            return ssoTexts.some(ssoText => text.includes(ssoText));
        });
    }
    
    // Fallback: tìm nút submit dark/primary trong form
    if (!ssoBtn) {
        ssoBtn = document.querySelector('button.sid-btn--dark[type="submit"]');
    }
    
    if (ssoBtn) {
        console.log('✅ Tìm thấy nút SSO:', ssoBtn.innerText || ssoBtn.textContent);
        
        // Thông báo background để theo dõi tab mới
        chrome.runtime.sendMessage({ 
            action: 'WATCH_FOR_NEW_TAB',
            returnUrl: currentUrl
        });
        
        await delay(500);
        ssoBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(300);
        ssoBtn.click();
        console.log('✅ Đã click nút SSO');
        
        showNotification('🔐 Đang mở trang đăng nhập trường...', 'Sẽ tự động đóng và quay lại');
        
    } else {
        console.log('⚠️ Không tìm thấy nút SSO');
    }
}

// ==================== UPLOAD PAGE HANDLING ====================

async function handleUploadPage() {
    const delay = ms => new Promise(r => setTimeout(r, ms));
    
    console.log('📤 Đang ở trang Upload, tìm nút Upload Proof...');
    
    await delay(1000);
    
    // Tìm nút "Upload Proof of Enrollment"
    const uploadBtn = document.querySelector('.sid-sso-pending-submit-btn') ||
                      document.querySelector('button[class*="pending"]') ||
                      [...document.querySelectorAll('button')].find(btn => 
                          (btn.innerText || '').toLowerCase().includes('upload proof')
                      );
    
    if (uploadBtn) {
        console.log('✅ Tìm thấy nút Upload Proof');
        
        uploadBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await delay(500);
        uploadBtn.click();
        console.log('✅ Đã click Upload Proof of Enrollment');
        
        // Cập nhật button và thông báo hoàn thành
        updateButton('✅ Hoàn thành!', 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)');
        showNotification('🎉 Hoàn thành!', 'Đã click Upload Proof of Enrollment');
        
        // Reset sau 5 giây
        setTimeout(() => {
            updateButton('🎓 Auto Fill Student', 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)');
            chrome.runtime.sendMessage({ action: 'PROCESS_COMPLETE' });
        }, 5000);
        
    } else {
        console.log('⚠️ Không tìm thấy nút Upload Proof');
    }
}

// Hiển thị thông báo trên trang
function showNotification(title, subtitle) {
    let notif = document.getElementById('ext-notification');
    if (!notif) {
        notif = document.createElement('div');
        notif.id = 'ext-notification';
        notif.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 999998;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 25px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            font-family: Arial, sans-serif;
            animation: slideIn 0.3s ease;
        `;
        document.body.appendChild(notif);
    }
    
    notif.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 5px;">${title}</div>
        <div style="font-size: 12px; opacity: 0.9;">${subtitle}</div>
    `;
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        if (notif) notif.remove();
    }, 5000);
}

// ==================== INITIALIZATION ====================

function init() {
    if (document.readyState === 'complete') {
        initPage();
    } else {
        window.addEventListener('load', initPage);
    }
}

function initPage() {
    createControlButton();
    checkAndHandlePage();
    
    // Theo dõi thay đổi DOM để detect khi trang chuyển sang SSO
    const observer = new MutationObserver(() => {
        checkAndHandlePage();
    });
    
    observer.observe(document.body, { 
        childList: true, 
        subtree: true,
        characterData: true
    });
}

// Kiểm tra và xử lý trang
let lastPageState = '';
function checkAndHandlePage() {
    const pageState = detectPageState();
    
    // Chỉ xử lý khi state thay đổi
    if (pageState !== lastPageState) {
        console.log('📄 Page state changed:', lastPageState, '→', pageState);
        lastPageState = pageState;
        
        if (pageState === 'SSO_PAGE') {
            console.log('🔐 Detected SSO page, auto handling in 2 seconds...');
            updateButton('🔐 SSO...', 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)');
            
            setTimeout(() => {
                handleSSOPage();
            }, 2000);
        }
        
        if (pageState === 'UPLOAD_PAGE') {
            console.log('📤 Detected Upload page, auto handling in 2 seconds...');
            updateButton('📤 Upload...', 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)');
            
            setTimeout(() => {
                handleUploadPage();
            }, 2000);
        }
    }
}

init();
