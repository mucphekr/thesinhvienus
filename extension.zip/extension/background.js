// Background Service Worker - Điều phối giữa các tab

let sessionData = {
    sheeridTabId: null,
    sheeridUrl: null,
    generatorTabId: null,
    autofillScript: null,
    status: 'idle',
    watchingForNewTab: false,
    waitingToFill: false,
    startedFromPopup: false,
    returnUrl: null
};

// Lắng nghe message từ content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('📨 Background received:', message.action);
    
    switch (message.action) {
        case 'START_FROM_POPUP':
            // Bắt đầu từ popup với URL được cung cấp
            startFromPopup(message.url);
            sendResponse({ success: true });
            break;
            
        case 'START_PROCESS':
            startProcess(message.url, sender.tab.id);
            sendResponse({ success: true });
            break;
            
        case 'SCRIPT_READY':
            sessionData.autofillScript = message.script;
            sessionData.status = 'ready';
            console.log('✅ Script received, length:', message.script.length);
            returnToSheerID();
            sendResponse({ success: true });
            break;
            
        case 'GET_SCRIPT':
            sendResponse({ 
                script: sessionData.autofillScript,
                status: sessionData.status 
            });
            break;
            
        case 'WATCH_FOR_NEW_TAB':
            // Bắt đầu theo dõi tab mới từ SSO
            sessionData.watchingForNewTab = true;
            sessionData.returnUrl = message.returnUrl;
            sessionData.sheeridTabId = sender.tab.id;
            console.log('👀 Watching for new tab, return URL:', message.returnUrl);
            sendResponse({ success: true });
            break;
            
        case 'PROCESS_COMPLETE':
            sessionData.status = 'idle';
            sessionData.autofillScript = null;
            sessionData.watchingForNewTab = false;
            console.log('🎉 Process completed!');
            sendResponse({ success: true });
            break;
            
        case 'GET_STATUS':
            sendResponse({ 
                status: sessionData.status,
                hasScript: !!sessionData.autofillScript 
            });
            break;
    }
    
    return true;
});

// Bắt đầu quy trình từ popup (với URL được dán vào)
async function startFromPopup(sheeridUrl) {
    console.log('🚀 Starting from popup with URL:', sheeridUrl);
    
    sessionData.status = 'generating';
    sessionData.sheeridUrl = sheeridUrl;
    sessionData.startedFromPopup = true;
    
    // Mở trang generator trực tiếp
    console.log('📂 Step 1: Opening generator page...');
    const newTab = await chrome.tabs.create({
        url: 'https://nguyenbaviet.io.vn/',
        active: true
    });
    
    sessionData.generatorTabId = newTab.id;
    console.log('📂 Opened generator tab:', newTab.id);
}

// Bắt đầu quy trình tạo thông tin
async function startProcess(sheeridUrl, tabId) {
    console.log('🚀 Starting process for:', sheeridUrl);
    
    sessionData.sheeridTabId = tabId;
    sessionData.sheeridUrl = sheeridUrl;
    sessionData.status = 'generating';
    
    // Mở trang generator trực tiếp
    console.log('📂 Step 1: Opening generator page...');
    const newTab = await chrome.tabs.create({
        url: 'https://nguyenbaviet.io.vn/',
        active: true
    });
    
    sessionData.generatorTabId = newTab.id;
    console.log('📂 Opened generator tab:', newTab.id);
}


// Quay lại trang SheerID
async function returnToSheerID() {
    console.log('🔙 Returning to SheerID');
    
    if (sessionData.generatorTabId) {
        try {
            await chrome.tabs.remove(sessionData.generatorTabId);
            console.log('❌ Closed generator tab');
        } catch (e) {
            console.log('Tab already closed');
        }
        sessionData.generatorTabId = null;
    }
    
    // Nếu bắt đầu từ popup (chưa có tab SheerID), mở trang mới
    if (sessionData.startedFromPopup && sessionData.sheeridUrl) {
        console.log('📄 Opening SheerID page from popup URL...');
        const sheeridTab = await chrome.tabs.create({
            url: sessionData.sheeridUrl,
            active: true
        });
        sessionData.sheeridTabId = sheeridTab.id;
        sessionData.waitingToFill = true;
        sessionData.startedFromPopup = false;
        console.log('📄 SheerID tab opened:', sheeridTab.id);
        return;
    }
    
    // Nếu đã có tab SheerID, quay lại và refresh
    if (sessionData.sheeridTabId) {
        try {
            // Chuyển về tab SheerID
            await chrome.tabs.update(sessionData.sheeridTabId, { active: true });
            console.log('🔄 Refreshing SheerID page...');
            
            // Refresh trang
            await chrome.tabs.reload(sessionData.sheeridTabId);
            
            // Đánh dấu đang chờ refresh xong để điền form
            sessionData.waitingToFill = true;
            
        } catch (e) {
            console.error('Error returning to SheerID:', e);
        }
    }
}

// Theo dõi tab mới được tạo (từ SSO login)
chrome.tabs.onCreated.addListener(async (tab) => {
    if (sessionData.watchingForNewTab) {
        console.log('🆕 New tab created:', tab.id, tab.pendingUrl || tab.url);
        
        // Đợi 3 giây rồi đóng tab mới
        setTimeout(async () => {
            try {
                // Đóng tab mới (trang login của trường)
                await chrome.tabs.remove(tab.id);
                console.log('❌ Closed SSO login tab:', tab.id);
                
                // Quay lại tab SheerID
                if (sessionData.sheeridTabId) {
                    await chrome.tabs.update(sessionData.sheeridTabId, { active: true });
                    
                    // Gửi thông báo đã hoàn thành
                    setTimeout(() => {
                        chrome.tabs.sendMessage(sessionData.sheeridTabId, {
                            action: 'SSO_COMPLETE'
                        }).catch(e => console.log('Message error:', e));
                    }, 500);
                }
                
                sessionData.watchingForNewTab = false;
                
            } catch (e) {
                console.error('Error handling SSO tab:', e);
            }
        }, 3000);
    }
});

// Lắng nghe khi tab được cập nhật
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Generator tab loaded
    if (tabId === sessionData.generatorTabId && changeInfo.status === 'complete') {
        console.log('📄 Generator page loaded');
        
        setTimeout(() => {
            chrome.tabs.sendMessage(tabId, { action: 'GENERATE_AND_COPY' })
                .catch(e => console.log('Message error:', e));
        }, 2500);
    }
    
    // SheerID tab loaded và sẵn sàng điền form
    if (tabId === sessionData.sheeridTabId && changeInfo.status === 'complete' && sessionData.waitingToFill) {
        console.log('🔄 SheerID page loaded, ready to fill form');
        sessionData.waitingToFill = false;
        
        // Đợi 2 giây sau khi trang load xong rồi điền form
        setTimeout(async () => {
            try {
                await chrome.tabs.sendMessage(sessionData.sheeridTabId, {
                    action: 'FILL_FORM',
                    script: sessionData.autofillScript
                });
                console.log('📝 Sent FILL_FORM message');
            } catch (e) {
                console.error('Error sending message:', e);
            }
        }, 2000);
    }
});

console.log('🔧 SheerID Auto Fill Extension loaded');
